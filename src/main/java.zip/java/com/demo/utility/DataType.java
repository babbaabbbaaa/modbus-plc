package com.demo.utility;

/**
 * @author Rocker Chen
 */
public enum DataType {

    DATE_TIME,
    INTEGER,
    FLOAT,
    STRING
}
