package com.demo.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PLCQualifiedProductCountModel {

    private Object qualifiedCount = 0;
    private Object notQualifiedCount = 0;
}
