package com.demo.enums;

public enum BarcodeDuplicateEnum {

    NONE,
    DUP,
    CONFIRMED
}
