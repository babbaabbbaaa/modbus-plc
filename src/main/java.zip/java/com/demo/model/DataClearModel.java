package com.demo.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataClearModel {

    private short productTypeId;
}
