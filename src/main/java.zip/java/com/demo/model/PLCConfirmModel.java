package com.demo.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PLCConfirmModel {

    private String barcode;
    private Integer productTypeId;
}
